<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} ?>

<span class="wppb-form-field-item wppb-form-field-email">
    <input type="email" name="wppb_default_form[<?php echo $fieldIndex; ?>]" <?php echo $fieldAttr; ?>>
</span>